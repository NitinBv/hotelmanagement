package com.eatza.restaurantsearch.service.kafkaservice;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.eatza.restaurantsearch.dto.ReviewsDto;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

import java.io.IOException;



@Service
public class KafkaConsumer {
	
	

	@KafkaListener(topics="updatelastvisited",groupId="group_id",containerFactory="kafkaListenerContainerFactory")
    public void triggermailtocustomer(ReviewsDto data) throws JsonParseException, JsonMappingException, IOException
  {
		
      System.out.println("Invoking consumer successful");
      System.out.println("Restaurant id is "+data.getRestaurantid());
      System.out.println("Customer id is "+data.getCustomerid());
  }
	

}
