package com.eatza.restaurantsearch.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter @Setter @NoArgsConstructor
public class ReviewsDto {
	
	private Long id;
	private Long rating;
	private String review;
	
	private Long customerid;
	
	private Long restaurantid;

	public ReviewsDto(Long id, Long rating, String review, Long customerid, Long restaurantid) {
		super();
		this.id = id;
		this.rating = rating;
		this.review = review;
		this.customerid = customerid;
		this.restaurantid = restaurantid;
	}

	

}
