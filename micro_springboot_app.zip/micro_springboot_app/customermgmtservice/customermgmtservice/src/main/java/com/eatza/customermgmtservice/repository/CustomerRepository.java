package com.eatza.customermgmtservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


import com.eatza.customermgmtservice.model.Customer;


public interface CustomerRepository extends JpaRepository<Customer, Long> {
	
	@Query(value = "SELECT * FROM customer_details WHERE email=:email and active = true",nativeQuery = true)
	Customer findByEmail(String email);
	
	
	

}
