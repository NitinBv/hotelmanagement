package com.eatza.customermgmtservice.service.customerserviceimpl;

import com.eatza.customermgmtservice.dto.CustomerDto;
import com.eatza.customermgmtservice.exception.CustomerException;
import com.eatza.customermgmtservice.model.Customer;

public interface CustomerService {

	Customer register(CustomerDto customerDto) throws CustomerException;

	Customer deactivate(Long customerid);

	Customer updateCustomer(CustomerDto customerDto);

}
