package com.eatza.customermgmtservice.service.customerserviceimpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.eatza.customermgmtservice.dto.CustomerDto;

import com.eatza.customermgmtservice.exception.CustomerException;
import com.eatza.customermgmtservice.model.Customer;
import com.eatza.customermgmtservice.repository.CustomerRepository;


@Service
public class CustomerServiceImpl implements CustomerService {
	
	
	
	@Autowired
	CustomerRepository customerRepository;
	


	@Override
	public Customer register(CustomerDto customerDto) throws CustomerException {
		
		Customer cust=validateCustomer(customerDto.getEmail());
		
		if(cust !=null) {
			throw new CustomerException("customer is already registered");
		}else {
			Customer customer = new Customer(customerDto.getName(), customerDto.getDesc(),customerDto.getEmail(), true);
			
			customerRepository.save(customer);
		}
		
		
		
		
		return cust;
	}
	
	
	public Customer validateCustomer(String name) {
		
		Customer cust = customerRepository.findByEmail(name);

		return cust;
	}


	@Override
	public Customer deactivate(Long customerid) {
		Optional<Customer> cust = customerRepository.findById(customerid);
		
		Customer cus = cust.get();
		
		cus.setActive(false);
		customerRepository.saveAndFlush(cus);
		
		return cus;
	}


	@Override
	public Customer updateCustomer(CustomerDto customerDto) {
		Optional<Customer> cust = customerRepository.findById(customerDto.getId());
		
		Customer cus = cust.get();
		
		cus.setActive(true);
		cus.setCustomer_desc(customerDto.getDesc());
		cus.setCustomer_name(customerDto.getName());
		cus.setEmail(customerDto.getEmail());
		customerRepository.saveAndFlush(cus);
		
		return cus;
		
	}
	
	

}
