package com.eatza.customermgmtservice.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eatza.customermgmtservice.dto.CustomerDto;
import com.eatza.customermgmtservice.exception.CustomerException;


import com.eatza.customermgmtservice.service.customerserviceimpl.CustomerService;





@RestController
@RequestMapping("/customerservice")
public class CustomerMgmtController {
	
	@Autowired
	CustomerService customerService;
	
	private static final Logger logger = LoggerFactory.getLogger(CustomerMgmtController.class);
	
	@PostMapping("/register")
	public ResponseEntity<String> registerCustomer(@RequestHeader String authorization, @RequestBody CustomerDto CustomerDto) throws CustomerException{
		logger.debug("In place order method, calling the service");
		customerService.register(CustomerDto);
		logger.debug("registered Successfully");
		return ResponseEntity
				.status(HttpStatus.CREATED)
				.body("Registered successfully");

	}
	
	@PutMapping("/deactivate/{customerid}")
	public ResponseEntity<String> deactivateCustomer(@RequestHeader String authorization, @PathVariable Long customerid) throws CustomerException{
		logger.debug("In place order method, calling the service");
		customerService.deactivate(customerid);
		logger.debug("Deactivated Successfully");
		return ResponseEntity
				.status(HttpStatus.OK)
				.body("Deactivated successfully");

	}
	
	@PutMapping("/changeCustomerdetails")
	public ResponseEntity<String> updateCustomer(@RequestHeader String authorization, @RequestBody CustomerDto CustomerDto) throws CustomerException{
		logger.debug("In place order method, calling the service");
		customerService.updateCustomer(CustomerDto);
		logger.debug("Updated Successfully");
		return ResponseEntity
				.status(HttpStatus.OK)
				.body("Updated successfully");

	}
	
	

	
}
