package com.eatza.customermgmtservice.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="customer_details")
@Getter @Setter @NoArgsConstructor
public class Customer {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long customer_id;
	
	private String customer_name;
	
	private String customer_desc;
	
	private String email;
	
	private Boolean active;
	
	

	public Customer( String customer_name, String customer_desc, String email, Boolean active
			) {
		super();
		
		this.customer_name = customer_name;
		this.customer_desc = customer_desc;
		this.email = email;
		this.active = active;
		
	}
}
