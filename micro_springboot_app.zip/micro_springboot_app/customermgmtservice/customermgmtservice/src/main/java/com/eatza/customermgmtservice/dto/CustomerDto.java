package com.eatza.customermgmtservice.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter @Setter @NoArgsConstructor
public class CustomerDto {
	
	private Long id;
	private String name;
	private String desc;
	private String email;
	private Boolean active;
	
	public CustomerDto(Long id, String name, String desc, String email, Boolean active) {
		super();
		this.id = id;
		this.name = name;
		this.desc = desc;
		this.email = email;
		this.active = active;
		
	}
	
	
	
	
	
	

}
