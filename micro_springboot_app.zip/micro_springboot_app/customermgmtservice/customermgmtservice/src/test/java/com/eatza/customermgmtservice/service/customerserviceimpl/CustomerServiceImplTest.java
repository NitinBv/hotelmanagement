package com.eatza.customermgmtservice.service.customerserviceimpl;



import org.junit.jupiter.api.BeforeEach;

import org.mockito.InjectMocks;
import org.mockito.Mock;

import org.springframework.boot.test.context.SpringBootTest;

import com.eatza.customermgmtservice.dto.CustomerDto;

import com.eatza.customermgmtservice.model.Customer;
import com.eatza.customermgmtservice.repository.CustomerRepository;


@SpringBootTest
class CustomerServiceImplTest {
	
	@InjectMocks
	CustomerServiceImpl customerServiceImpl;
	
	@Mock
	CustomerRepository customerRepository;
	
	String email = "niti.varur@mindtree.com";
	
	Customer customer;
	
	CustomerDto customerDto;
	
	@BeforeEach
	public void init() {
		customerDto = new CustomerDto(1L, "Nitin", "new customer", "nitin.var", true);
		customer = new Customer("Nitin", "new customer", "nitin.var", true);
	}

//	@Test
//	void testRegister() throws CustomerException {
//		Mockito.when(customerRepository.findByEmail(email)).thenReturn(customer);
//		Mockito.when(customerServiceImpl.validateCustomer(email)).thenReturn(customer);
//		assertEquals(customerServiceImpl.register(customerDto),customer );
//
//	}

}
