package com.eatza.customermgmtservice.controller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;

import com.eatza.customermgmtservice.dto.CustomerDto;
import com.eatza.customermgmtservice.exception.CustomerException;
import com.eatza.customermgmtservice.model.Customer;
import com.eatza.customermgmtservice.service.customerserviceimpl.CustomerService;


@SpringBootTest
class CustomerMgmtControllerTest {

	@InjectMocks
	CustomerMgmtController customerMgmtController;
	
	@Mock
	CustomerService customerService;
	
	CustomerDto customerDto;
	
	Customer customer;
	Long customerid;
	
	@BeforeEach
	public void init() {
		customerDto = new CustomerDto(1L, "Nitin", "new customer", "nitin.var", true);
		CustomerDto customerDt = new CustomerDto();
		customerDt.setId(1L);
		customerDt.setDesc("vsghdvgsad");
		customerDt.setEmail("nitinbvarur");
		customerDt.setName("Nitin");
		customerDt.setActive(true);
		customer = new Customer("Nitin", "new customer", "nitin.var", true);
		
		 customerid= 1L;
	}
	
	
	@Test
	void testRegisterCustomer() throws CustomerException {
		Mockito.when(customerService.register(customerDto)).thenReturn(customer);
		assertEquals(customerMgmtController.registerCustomer("user-password", customerDto).getStatusCode(), HttpStatus.CREATED);

	}

	@Test
	void testDeactivateCustomer() throws CustomerException {
		Mockito.when(customerService.deactivate(customerid)).thenReturn(customer);
		assertEquals(customerMgmtController.deactivateCustomer("user-password", customerid).getStatusCode(), HttpStatus.OK);
	}

	@Test
	void testUpdateCustomer() throws CustomerException {
		Mockito.when(customerService.updateCustomer(customerDto)).thenReturn(customer);
		assertEquals(customerMgmtController.updateCustomer("user-password", customerDto).getStatusCode(), HttpStatus.OK);
	}

}
