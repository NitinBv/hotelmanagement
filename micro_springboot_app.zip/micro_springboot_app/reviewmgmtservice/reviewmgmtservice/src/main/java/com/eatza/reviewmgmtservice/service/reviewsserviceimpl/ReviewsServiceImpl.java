package com.eatza.reviewmgmtservice.service.reviewsserviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eatza.reviewmgmtservice.dto.ReviewsDto;
import com.eatza.reviewmgmtservice.exception.ReviewException;
import com.eatza.reviewmgmtservice.model.Reviews;
import com.eatza.reviewmgmtservice.repository.ReviewsRepository;


@Service
public class ReviewsServiceImpl implements ReviewsService {
	

	@Autowired
	ReviewsRepository reviewsRepository;
	

    
	

	@Override
	public List<Reviews> fetchAllReviews() {
		
		List<Reviews> views = reviewsRepository.findAll();
		
		return views;
	}

	@Override
	public Reviews createReview(ReviewsDto dto) throws ReviewException {
		Reviews rev;
		Reviews view =  validateReview(dto);
		
		
		
		if(view != null) {
			throw new ReviewException("Review already exists for the customer and restuarant");
		}else {
			
//			updateLastVisitedForCust();
			
			 rev =  new Reviews(dto.getRating(), dto.getReview(), dto.getCustomerid(), dto.getRestaurantid());
			 
			reviewsRepository.saveAndFlush(rev);
		}
		
return rev;
		
	}
	
//	public String updateLastVisitedForCust() {
//		
//		logger.info("Sending  to the KAFKA topic to process...");
//		kafkaTemplate.send(CREATE_ACCOUNT_TOPIC,"review submitted successfully");
//		
//		return "Updated successfully";
//		
//	}
	
	private Reviews validateReview(ReviewsDto dto) {
		return reviewsRepository.findByIds(dto.getCustomerid(), dto.getRestaurantid());
	}

	@Override
	public Reviews updateReview(ReviewsDto dto) {
		Optional<Reviews> views = reviewsRepository.findById(dto.getId());
		
		Reviews view = views.get();
		
		
		
//		view.setCustomerid(dto.getCustomerid());
//		view.setRestaurantid(dto.getRestaurantid());
		view.setRating(dto.getRating());
		view.setReview(dto.getReview());
		
		reviewsRepository.saveAndFlush(view);
		
		return view;
		
		
		
		}
	
	
	
}
