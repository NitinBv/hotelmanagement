package com.eatza.reviewmgmtservice.service.reviewsserviceimpl;

import java.util.List;

import com.eatza.reviewmgmtservice.dto.ReviewsDto;
import com.eatza.reviewmgmtservice.exception.ReviewException;
import com.eatza.reviewmgmtservice.model.Reviews;

public interface ReviewsService {

	List<Reviews> fetchAllReviews();

	Reviews createReview(ReviewsDto dto) throws ReviewException;

	Reviews updateReview(ReviewsDto dto);

	

}
