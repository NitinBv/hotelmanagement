package com.eatza.reviewmgmtservice.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.eatza.reviewmgmtservice.dto.ReviewsDto;
import com.eatza.reviewmgmtservice.exception.ReviewException;
import com.eatza.reviewmgmtservice.model.Reviews;
import com.eatza.reviewmgmtservice.service.reviewsserviceimpl.ReviewsService;

@RestController
@RequestMapping("/reviewservice")
public class ReviewMgmtController {
	
	
	@Autowired
	ReviewsService reviewsService;
	
	@Autowired
	private KafkaTemplate<String, ReviewsDto> kafkaTemplate;

    private static final String CREATE_ACCOUNT_TOPIC = "updatelastvisited";
	
	private static final Logger logger = LoggerFactory.getLogger(ReviewMgmtController.class);
	
	@GetMapping("/allreviews")
	public ResponseEntity<List<Reviews>> viewreviews(@RequestHeader String authorization) throws ReviewException{
		logger.debug("In get order by id method, calling service to get Order by ID");
		List<Reviews> reviews = reviewsService.fetchAllReviews();
		if(reviews.size() > 0) {
			logger.debug("Got order from service");
			return ResponseEntity
					.status(HttpStatus.OK)
					.body(reviews);
		}
		else {
			logger.debug("No orders were found");
			throw new ReviewException("No result found for specified inputs");
		}
	}
	
	
	
	@PostMapping("/newReview")
	public ResponseEntity<String> createReview(@RequestHeader String authorization, @RequestBody ReviewsDto dto) throws ReviewException{
		logger.debug("In place order method, calling the service");
		logger.info("Sending  to the KAFKA topic to process...");
		kafkaTemplate.send(CREATE_ACCOUNT_TOPIC,dto);
		reviewsService.createReview(dto);
		logger.debug("Created Successfully");
		return ResponseEntity
				.status(HttpStatus.CREATED)
				.body("Created successfully");

	}
	
	@PutMapping("/changeReviewdetails")
	public ResponseEntity<String> updateReview(@RequestHeader String authorization, @RequestBody ReviewsDto dto) {
		logger.debug("In place order method, calling the service");
		reviewsService.updateReview(dto);
		logger.debug("Updated Successfully");
		return ResponseEntity
				.status(HttpStatus.OK)
				.body("Updated successfully");

	}

}
