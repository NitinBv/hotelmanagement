package com.eatza.reviewmgmtservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


import com.eatza.reviewmgmtservice.model.Reviews;

public interface ReviewsRepository extends JpaRepository<Reviews, Long>{

	@Query(value = "SELECT * FROM reviews WHERE customerid=:custid and restaurantid =:restid",nativeQuery = true)
	Reviews findByIds(Long custid,Long restid);
	
}
