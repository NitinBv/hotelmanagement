package com.eatza.reviewmgmtservice.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="reviews")
@Getter @Setter @NoArgsConstructor
public class Reviews {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	private Long rating;
	private String review;
	
	private Long customerid;
	
	private Long restaurantid;

	public Reviews(Long rating, String review, Long customerid, Long restaurantid) {
		super();
		
		this.rating = rating;
		this.review = review;
		this.customerid = customerid;
		this.restaurantid = restaurantid;
	}
	
	

}
