package com.eatza.reviewmgmtservice.controller;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;

import com.eatza.reviewmgmtservice.dto.ReviewsDto;
import com.eatza.reviewmgmtservice.exception.ReviewException;
import com.eatza.reviewmgmtservice.model.Reviews;
import com.eatza.reviewmgmtservice.service.reviewsserviceimpl.ReviewsService;


@SpringBootTest
class ReviewMgmtControllerTest {
	
	@InjectMocks
	ReviewMgmtController reviewMgmtController;
	
	@Mock
	ReviewsService reviewsService;
	
	Long customerid;
	Long restaurantid;
	ReviewsDto reviewsDto;
	Reviews reviews;
	
	List list;
	
	@BeforeEach
	public void init() {
		customerid = 1L;
		restaurantid = 1L;
		reviews =  new Reviews(1L, "poor", customerid, restaurantid);
		reviewsDto = new ReviewsDto(3L, 1L,"poor", customerid, restaurantid);
		
		list = new ArrayList<>();
	Reviews r1 = new Reviews(4L, "good", customerid, restaurantid);
	Reviews r2 = new Reviews(3L, "very good", customerid, restaurantid);
	
	list.add(r1);
	list.add(r2);
	}

	@SuppressWarnings("unchecked")
	@Test
	void testViewreviews() throws ReviewException {
		Mockito.when(reviewsService.fetchAllReviews()).thenReturn(list);
		assertEquals(reviewMgmtController.viewreviews("user-password").getStatusCode(), HttpStatus.OK);
	}

	@Test
	void testCreateReview() throws ReviewException {
		Mockito.when(reviewsService.createReview(reviewsDto)).thenReturn(reviews);
		assertEquals(reviewMgmtController.createReview("user-password", reviewsDto).getStatusCode(), HttpStatus.CREATED);
		
	}

	@Test
	void testUpdateReview() {
		Mockito.when(reviewsService.updateReview(reviewsDto)).thenReturn(reviews);
		assertEquals(reviewMgmtController.updateReview("user-password", reviewsDto).getStatusCode(), HttpStatus.OK);
	
	}

}
