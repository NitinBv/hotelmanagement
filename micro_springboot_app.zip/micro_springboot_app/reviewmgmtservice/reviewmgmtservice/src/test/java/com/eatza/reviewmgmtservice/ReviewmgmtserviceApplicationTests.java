package com.eatza.reviewmgmtservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReviewmgmtserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
